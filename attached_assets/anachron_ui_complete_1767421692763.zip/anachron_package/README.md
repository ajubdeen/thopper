# Anachron UI Assets Package

Drop-in UI components and assets for the Anachron home screen.

## Package Contents

```
public/
└── assets/
    ├── anachron-bg-simple.png      # New user background
    ├── anachron-bg-full.png        # Returning user background (with saves UI)
    └── eras/                       
        ├── greece.png              # Classical Athens
        ├── viking.png              # Viking Age
        ├── medival.png             # Medieval Europe
        ├── AmericanRevolution.png  # Colonial America
        ├── industrial.png          # Industrial Britain
        ├── American_civil_war.png  # American Civil War
        ├── ww2Europe.png           # WWII Occupied Europe
        ├── WW2Homefront.png        # WWII American Home Front
        └── coldwar.png             # Cold War East Germany

src/
├── components/anachron/
│   ├── index.ts              
│   ├── types.ts              # Types + ERA_THUMBNAILS mapping
│   ├── SteampunkButton.tsx   
│   └── SavedTimelineCard.tsx 
├── pages/
│   └── HomePage.tsx          
└── styles/
    └── anachron.css          
```

## Installation

1. Copy `public/assets/` to your Replit `public/` folder
2. Copy `src/components/anachron/` to your `src/components/`
3. Copy `src/pages/HomePage.tsx` to your `src/pages/`
4. Copy `src/styles/anachron.css` to your `src/styles/`
5. Import the CSS in your App.tsx:

```tsx
import "./styles/anachron.css";
```

## Usage

```tsx
import { HomePage } from "./pages/HomePage";
import { TimelineSave } from "./components/anachron/types";

// Convert your backend saves to TimelineSave format
const savedGames: TimelineSave[] = backendSaves.map(save => ({
  id: save.game_id,
  game_id: save.game_id,
  playerName: save.player_name,
  era: save.current_era,  // e.g., "classical_athens" or "Classical Athens"
  year: String(save.era_year || ""),
  turn: save.total_turns,
  status: inferStatus(save.total_turns),  // "thriving" | "struggling" | "surviving" | "just_started"
}));

<HomePage
  savedGames={savedGames}
  onNewGame={() => socket.emit('new_game')}
  onResumeGame={(save) => socket.emit('load_game', { game_id: save.game_id })}
  onDeleteGame={(save) => socket.emit('delete_game', { game_id: save.game_id })}
  onViewAnnals={() => setPhase("leaderboard")}
/>
```

## Era Thumbnail Mapping

The `ERA_THUMBNAILS` object in `types.ts` maps both era IDs and display names:

```typescript
// Works with either format
getEraThumbnail("classical_athens")        // -> "/assets/eras/greece.png"
getEraThumbnail("Classical Athens")        // -> "/assets/eras/greece.png"
```

Eras without images (Ancient Egypt, Aztec Empire, Indian Partition) return `null`.
